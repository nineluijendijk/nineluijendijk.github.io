utils::globalVariables(c("Count", "Term", "aes", "log2FoldChange", "padj", "cases", "countriesAndTerritories", "day", "element_text", "month", "year", "desc"))
